package Lab3.Ej4;

public class H3 extends H1 {
    public void dispH3()
    {
        System.out.println("Method of ClassH3");
    }
}
