package Lab3.Ej4;

public class H1 {
    public void dispH1()
    {
        System.out.println("Method of ClassH1");
    }
}
