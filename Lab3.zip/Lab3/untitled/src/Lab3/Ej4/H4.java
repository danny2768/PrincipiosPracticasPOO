package Lab3.Ej4;

public class H4 extends H1 {
    public void dispH4()
    {
        System.out.println("Method of ClassH4");
    }
}
