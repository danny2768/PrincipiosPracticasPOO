package Lab3.Ej1;

public class A
{
    int a, b;
    void display()
    {
        System.out.println("Inside class A values ="+a+" "+b);
    }
}

