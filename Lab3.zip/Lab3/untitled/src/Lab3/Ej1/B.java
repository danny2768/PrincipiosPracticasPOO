package Lab3.Ej1;

public class B extends A
{
    int c;
    void show()
    {
        System.out.println("Inside Class B values="+a+" "+b+" "+c);  }
}

