package Lab3.Ej1;

public class HerenciaUnica {
    public static void main(String args[])
    {
        B obj = new B();
        obj.a=10;
        obj.b=20;
        obj.c=30;
        obj.display();
        obj.show();
    }
}
