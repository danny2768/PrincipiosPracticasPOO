package Lab3.Ej3;

public class Lobo extends Canino{
    public void hacerRuido() {
        System.out.println("Aauuuuuuu");
    }
}
