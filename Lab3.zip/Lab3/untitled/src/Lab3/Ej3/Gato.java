package Lab3.Ej3;

public class Gato extends Felino{
    public void hacerRuido() {
        System.out.println("Miau Miau");
    }
}
