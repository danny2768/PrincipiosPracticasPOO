package Lab3.Ej3;

public class Canino extends Animal {
    public void desplazarse() {
        System.out.println("Desplazamiento en manada");
    }
}


