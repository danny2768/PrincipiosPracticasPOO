package Lab3.Ej3;

public class Felino extends Animal {
    public void desplazarse() {
        System.out.println("Desplazamiento solitario");
    }
}
