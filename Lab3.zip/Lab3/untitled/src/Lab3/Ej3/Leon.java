package Lab3.Ej3;

public class Leon extends Felino{
    public void hacerRuido() {
        System.out.println("Grrrrrrr");
    }
}
