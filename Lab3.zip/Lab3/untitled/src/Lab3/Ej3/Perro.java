package Lab3.Ej3;

public class Perro extends Canino{
    public void hacerRuido() {
        System.out.println("Guau Guau");
    }
}
